CREATE TABLE Incident_Dim (
	Incident_key INT NOT NULL IDENTITY,
	Incident_number VARCHAR(20) NOT NULL,
	incident_location VARCHAR(20),
	caller_id VARCHAR(30),
	contact_type VARCHAR(20),
	sys_created_at DATETIME,
	closed_at DATETIME,
	PRIMARY KEY (Incident_key))
GO

CREATE TABLE Calendar_Dim (	
	Calendar_key INT NOT NULL IDENTITY,
	opened_at DATETIME,
	DayofWeek_ CHAR(15),
	DayType CHAR(20),
	DayofMonth_ INT,
	Month_	CHAR(10),
	Quarter_ CHAR(2),
	Year_ INT,
	PRIMARY KEY (Calendar_key))
GO



CREATE TABLE Category_Dim (
	Category_key INT NOT NULL IDENTITY,
	category  VARCHAR(30),
	subcategory VARCHAR(30),
	PRIMARY KEY (Category_key))
GO

CREATE TABLE Priority_Dim (
	Priority_key INT NOT NULL IDENTITY,
	category  VARCHAR(30),
	impact VARCHAR(30), 
	urgency VARCHAR(30),
	incident_priority VARCHAR(30),
	PRIMARY KEY (Priority_key))
GO

CREATE TABLE Status_Dim (
	Status_Key INT NOT NULL IDENTITY,
	incident_state VARCHAR(20) ,
	active VARCHAR(20),  
	PRIMARY KEY (Status_Key))
GO


CREATE TABLE Incident_Fact (
	Incident_Fact_Key INT NOT NULL IDENTITY,
	Incident_key INT,
	Category_key INT,
	Priority_key INT,
	Status_Key INT,
	Calendar_key INT,
	made_sla VARCHAR(20),
	reopen_count INT,
	reassignment_count INT,
	sys_mod_count INT,
	notify VARCHAR(30),
	PRIMARY KEY(Incident_Fact_Key),
	FOREIGN KEY (Incident_key) REFERENCES Incident_Dim (Incident_key),
	FOREIGN KEY (Calendar_key) REFERENCES Calendar_Dim (Calendar_key),
	FOREIGN KEY (Category_key) REFERENCES Category_Dim (Category_key),
	FOREIGN KEY (Priority_key) REFERENCES Priority_Dim (Priority_key),
	FOREIGN KEY (Status_Key) REFERENCES Status_Dim (Status_Key))
GO